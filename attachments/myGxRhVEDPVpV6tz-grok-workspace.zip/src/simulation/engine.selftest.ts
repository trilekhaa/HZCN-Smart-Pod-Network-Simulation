import { SimulationEngine } from "@/simulation/SimulationEngine";
import {
  DEVICES_PER_ZONE,
  HEARTBEAT_TIMEOUT,
  PRIMARY_ATTACK_DEVICE,
  SCHEDULED_ATTACK_AT,
  SCHEDULED_FAILURE_AT,
  SIMULATION_DURATION,
  ZONE_IDS,
} from "@/models/types";

export function runEngineSelfTest(): string[] {
  const errors: string[] = [];
  const engine = new SimulationEngine();
  if (engine.state.devices.length !== 120) errors.push(`devices ${engine.state.devices.length}`);
  if (engine.state.pods.length !== 8) errors.push(`pods ${engine.state.pods.length}`);
  if (engine.state.zones.length !== 5) errors.push(`zones ${engine.state.zones.length}`);
  if (engine.state.links.length !== 16) errors.push(`links ${engine.state.links.length}`);
  if (engine.state.core.distributionCapacityMbps !== 1000) {
    errors.push(`distribution capacity ${engine.state.core.distributionCapacityMbps}`);
  }
  for (const zone of ZONE_IDS) {
    const count = engine.state.devices.filter((d) => d.zone === zone).length;
    if (count !== DEVICES_PER_ZONE) errors.push(`${zone} devices ${count}`);
  }
  if (!engine.state.devices.some((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)) {
    errors.push("Student-027 missing");
  }

  engine.start();
  engine.stepN(SCHEDULED_ATTACK_AT - 1);
  const before = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  if (before.currentSecurityState !== "CLEAR ACCESS") {
    errors.push(`pre-attack state ${before.currentSecurityState}`);
  }
  if (engine.state.scenario.scheduledAttackFired) errors.push("attack fired early");

  engine.stepN(1);
  if (engine.state.currentTime !== SCHEDULED_ATTACK_AT) {
    errors.push(`attack tick ${engine.state.currentTime}`);
  }
  if (!engine.state.scenario.scheduledAttackFired) errors.push("attack did not start at t=45");

  engine.stepN(10);
  const attacker = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  if (attacker.threatScore < 40) errors.push(`threat ${attacker.threatScore}`);
  if (attacker.policyViolations < 1) errors.push("no policy violations");
  if (attacker.currentSecurityState === "CLEAR ACCESS") errors.push("attacker still clear");

  while (
    engine.state.currentTime < SCHEDULED_FAILURE_AT - 1 &&
    attacker.currentSecurityState !== "RESTRICTED ISOLATION" &&
    attacker.currentSecurityState !== "NETWORK-WIDE QUARANTINE"
  ) {
    engine.step();
  }
  const escalated = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  if (
    escalated.currentSecurityState !== "RESTRICTED ISOLATION" &&
    escalated.currentSecurityState !== "NETWORK-WIDE QUARANTINE" &&
    escalated.currentSecurityState !== "BANDWIDTH THROTTLED"
  ) {
    errors.push(`no isolation/throttle ${escalated.currentSecurityState}`);
  }

  const remainingToFailure = SCHEDULED_FAILURE_AT - engine.state.currentTime;
  if (remainingToFailure > 0) engine.stepN(remainingToFailure);
  if (engine.state.currentTime !== SCHEDULED_FAILURE_AT) {
    errors.push(`failure tick ${engine.state.currentTime}`);
  }
  const podAtFail = engine.state.pods.find((p) => p.podId === "POD-01")!;
  const primaryAtFail = engine.state.links.find((l) => l.id === podAtFail.primaryLink)!;
  if (!primaryAtFail.failed) errors.push("primary not failed at t=75");
  if (engine.state.failover.phase === "idle") errors.push("failover timing idle at t=75");
  const preFailover = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  const isolatedState = preFailover.currentSecurityState;

  engine.stepN(1);
  const afterFail = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  if (isolatedState !== "CLEAR ACCESS" && afterFail.currentSecurityState === "CLEAR ACCESS") {
    errors.push(`failover reset security ${isolatedState} -> ${afterFail.currentSecurityState}`);
  }
  const pod = engine.state.pods.find((p) => p.podId === "POD-01")!;
  if (pod.status !== "failover") errors.push(`pod status ${pod.status}`);
  const primary = engine.state.links.find((l) => l.id === pod.primaryLink)!;
  const backup = engine.state.links.find((l) => l.id === pod.backupLink)!;
  if (!primary.failed) errors.push("primary not failed");
  if (backup.status !== "active") errors.push(`backup ${backup.status}`);
  if (engine.state.failover.heartbeatTimeoutMs !== HEARTBEAT_TIMEOUT * 1000) {
    errors.push(`heartbeat config ${engine.state.failover.heartbeatTimeoutMs}`);
  }
  if (engine.state.failover.failoverDurationMs == null) errors.push("failover duration not measured");

  const types = new Set(engine.state.events.map((e) => e.eventType));
  for (const needed of [
    "ATTACK_INJECTED",
    "POLICY_VIOLATION",
    "LINK_FAILURE",
    "HEARTBEAT_TIMEOUT",
    "FAILOVER_ACTIVATED",
    "STATE_SYNCHRONIZED",
    "ROUTE_RECALCULATED",
  ] as const) {
    if (!types.has(needed)) errors.push(`missing event ${needed}`);
  }

  engine.stepN(SIMULATION_DURATION - engine.state.currentTime);
  if (engine.state.currentTime !== SIMULATION_DURATION) {
    errors.push(`final time ${engine.state.currentTime}`);
  }
  if (!engine.state.scenario.completed) errors.push("simulation did not complete");

  const invalid = engine.state.devices.filter(
    (d) => d.threatScore < 0 || d.threatScore > 100 || !d.connectedPod,
  );
  if (invalid.length) errors.push(`invalid device state ${invalid.length}`);

  return errors;
}
