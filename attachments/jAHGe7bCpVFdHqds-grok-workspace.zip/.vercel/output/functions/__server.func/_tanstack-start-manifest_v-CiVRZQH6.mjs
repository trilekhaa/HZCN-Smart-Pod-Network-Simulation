//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CiVRZQH6.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/analytics",
			"/attack",
			"/logs",
			"/security",
			"/topology",
			"/api/analytics",
			"/api/devices",
			"/api/events",
			"/api/pods",
			"/api/zones",
			"/api/simulation/attack",
			"/api/simulation/congestion",
			"/api/simulation/failure",
			"/api/simulation/reset",
			"/api/simulation/start",
			"/api/simulation/state"
		],
		preloads: ["/assets/index-CxuhY8Fw.js", "/assets/simulation-store-DpRajoqv.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CxuhY8Fw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DLA99VAW.js",
			"/assets/DpqMeters-DodrZfAo.js",
			"/assets/card-CxN1nfEu.js",
			"/assets/EventList-CvixpIbu.js",
			"/assets/TopologyView-BIbk1pwb.js"
		]
	},
	"/analytics": {
		filePath: "/workspace/src/routes/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-BsSJRKs0.js",
			"/assets/DpqMeters-DodrZfAo.js",
			"/assets/card-CxN1nfEu.js"
		]
	},
	"/attack": {
		filePath: "/workspace/src/routes/attack.tsx",
		children: void 0,
		preloads: [
			"/assets/attack-CGuFIY3G.js",
			"/assets/card-CxN1nfEu.js",
			"/assets/EventList-CvixpIbu.js",
			"/assets/select-aVDnMlVZ.js"
		]
	},
	"/logs": {
		filePath: "/workspace/src/routes/logs.tsx",
		children: void 0,
		preloads: ["/assets/logs-ClyYk8da.js", "/assets/select-aVDnMlVZ.js"]
	},
	"/security": {
		filePath: "/workspace/src/routes/security.tsx",
		children: void 0,
		preloads: ["/assets/security-eD9EO5SP.js", "/assets/select-aVDnMlVZ.js"]
	},
	"/topology": {
		filePath: "/workspace/src/routes/topology.tsx",
		children: void 0,
		preloads: [
			"/assets/topology-DVQdU-Fi.js",
			"/assets/card-CxN1nfEu.js",
			"/assets/TopologyView-BIbk1pwb.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
