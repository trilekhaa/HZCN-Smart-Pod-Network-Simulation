import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as eventTone } from "./labels-CM2fqjAt.mjs";
import { t as Badge } from "./badge-D_nOJ4GH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/EventList-CN1BCoSX.js
var import_jsx_runtime = require_jsx_runtime();
function EventList({ events, empty = "No events yet." }) {
	if (events.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-border",
		children: events.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex flex-col gap-1 py-3 first:pt-0 last:pb-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-xs text-accent tabular",
						children: [
							"t=",
							event.simulationTime,
							"s"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: eventTone(event.eventType),
						children: event.eventType
					}),
					event.deviceId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: event.deviceId
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg/90",
				children: event.description
			})]
		}, event.id))
	});
}
//#endregion
export { EventList as t };
