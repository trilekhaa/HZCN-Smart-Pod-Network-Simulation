import { h as useSimulation, m as useSimStore, u as cn } from "./simulation-store-yCXKmLbM.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as ZONE_LABEL } from "./labels-CM2fqjAt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/TopologyView-inTAf0Yc.js
var import_jsx_runtime = require_jsx_runtime();
var ZONE_ORDER = [
	"academic",
	"student",
	"administration",
	"surveillance",
	"iot"
];
function linkColor(link) {
	if (link.status === "failed" || link.failed) return "stroke-danger";
	if (link.status === "congested") return "stroke-warn";
	if (link.status === "active") return "stroke-accent";
	if (link.status === "standby") return "stroke-subtle";
	return "stroke-ok";
}
function podGlow(pod) {
	if (pod.status === "failover") return "glow-pod-warn";
	if (pod.status === "degraded") return "glow-pod-warn";
	if (pod.status === "offline") return "glow-pod-danger";
	return "glow-pod";
}
function TopologyView({ compact = false }) {
	const snapshot = useSimulation();
	const select = useSimStore((s) => s.selectDevice);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 flex flex-col items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-accent/30 bg-elevated px-6 py-3 text-center shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Core"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-sm text-accent",
						children: snapshot.core.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"Health ",
							snapshot.core.networkHealth.toFixed(0),
							" · Links ",
							snapshot.core.activeLinks,
							" up /",
							" ",
							snapshot.core.failedLinks,
							" failed"
						]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5",
			children: ZONE_ORDER.map((zoneId) => {
				const zone = snapshot.zones.find((z) => z.id === zoneId);
				const pods = snapshot.pods.filter((p) => p.zone === zoneId);
				const devices = snapshot.devices.filter((d) => d.zone === zoneId);
				const preview = compact ? devices.slice(0, 12) : devices;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: ZONE_LABEL[zoneId]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									zone.cidr,
									" · ",
									zone.deviceCount,
									" devices"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: pods.map((pod) => {
								const primary = snapshot.links.find((l) => l.id === pod.primaryLink);
								const backup = snapshot.links.find((l) => l.id === pod.backupLink);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: cn("flex size-12 items-center justify-center rounded-full bg-bg font-mono text-[0.65rem] text-accent", podGlow(pod)),
										title: pod.podName,
										children: pod.podId.replace("POD-0", "P")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkTick, {
											link: primary,
											label: "P"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkTick, {
											link: backup,
											label: "B"
										})]
									})]
								}, pod.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("mt-3 grid gap-1", compact ? "grid-cols-6" : "grid-cols-6 sm:grid-cols-8"),
							children: preview.map((device) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceDot, {
								device,
								onClick: () => select(device.id)
							}, device.id))
						}),
						compact && devices.length > preview.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-[0.7rem] text-subtle",
							children: [
								"+",
								devices.length - preview.length,
								" more"
							]
						}) : null
					]
				}, zoneId);
			})
		})]
	});
}
function LinkTick({ link, label }) {
	if (!link) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("font-mono text-[0.6rem]", linkColor(link).replace("stroke-", "text-")),
		title: `${link.name} · ${link.status}`,
		children: label
	});
}
function DeviceDot({ device, onClick }) {
	const tone = device.currentSecurityState === "NETWORK-WIDE QUARANTINE" ? "bg-danger" : device.currentSecurityState === "RESTRICTED ISOLATION" ? "bg-warn" : device.currentSecurityState === "BANDWIDTH THROTTLED" ? "bg-accent" : device.currentSecurityState === "HEURISTIC ALERT" ? "bg-warn/70" : "bg-ok";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		title: `${device.deviceName} · ${device.currentSecurityState}`,
		className: cn("size-3 rounded-full", tone),
		"aria-label": device.deviceName
	});
}
//#endregion
export { TopologyView as t };
