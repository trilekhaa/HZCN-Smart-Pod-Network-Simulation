//#region node_modules/.nitro/vite/services/ssr/assets/labels-CM2fqjAt.js
var ZONE_LABEL = {
	academic: "Academic",
	student: "Student",
	administration: "Administration",
	surveillance: "Surveillance",
	iot: "IoT Laboratory"
};
function stateTone(state) {
	switch (state) {
		case "CLEAR ACCESS": return "ok";
		case "HEURISTIC ALERT": return "warn";
		case "BANDWIDTH THROTTLED": return "default";
		case "RESTRICTED ISOLATION": return "warn";
		case "NETWORK-WIDE QUARANTINE": return "danger";
		default: return "muted";
	}
}
function eventTone(type) {
	if (type.includes("BLOCKED") || type.includes("FAILURE") || type === "DEVICE_ISOLATED") return "danger";
	if (type.includes("THROTTLED") || type.includes("VIOLATION") || type.includes("SCAN") || type.includes("ATTACK")) return "warn";
	if (type.includes("FAILOVER") || type.includes("STARTED")) return "default";
	return "muted";
}
//#endregion
export { eventTone as n, stateTone as r, ZONE_LABEL as t };
