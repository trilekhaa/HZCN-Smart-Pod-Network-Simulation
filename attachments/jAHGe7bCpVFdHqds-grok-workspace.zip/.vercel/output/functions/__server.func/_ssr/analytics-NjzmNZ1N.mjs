import { h as useSimulation } from "./simulation-store-yCXKmLbM.mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as LossChart, c as SecurityTrendChart, d as ZoneTrafficChart, i as DpqMeters, l as ThreatChart, n as CountsChart, o as PdrChart, r as DelayChart, t as ActiveDevicesChart, u as ThroughputChart } from "./DpqMeters-fvPRB_1w.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-CuNkRt-S.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analytics-NjzmNZ1N.js
var import_jsx_runtime = require_jsx_runtime();
function AnalyticsPage() {
	const sim = useSimulation();
	const empty = sim.history.length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Network analytics"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-2xl font-medium tracking-tight",
				children: "Computed from the live engine"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted",
				children: "Every series is a history buffer written once per simulated second. Start the clock to populate charts."
			})
		] }), empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "py-10 text-center text-sm text-muted",
			children: "No samples yet. Start the simulation to record throughput, delay, loss, and threat history."
		}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThroughputChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LossChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PdrChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DelayChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreatChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoneTrafficChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActiveDevicesChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecurityTrendChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountsChart, { data: sim.history }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "DPQ class pressure" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DpqMeters, { dpq: sim.dpq }) })] })
			]
		})]
	});
}
//#endregion
export { AnalyticsPage as component };
