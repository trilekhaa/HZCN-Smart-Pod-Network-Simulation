import { createFileRoute } from "@tanstack/react-router";
import { TopologyView } from "@/components/topology/TopologyView";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useSimulation } from "@/store/simulation-store";

export const Route = createFileRoute("/topology")({ component: TopologyPage });

function TopologyPage() {
  const sim = useSimulation();
  return (
    <div className="space-y-6">
      <div>
        <p className="kicker">Campus topology</p>
        <h2 className="mt-1 text-2xl font-medium tracking-tight">Virtual network map</h2>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Core switch, five security zones, eight Smart Pods, and 120 virtual devices. Link color reflects
          simulated health. Click a device for details.
        </p>
      </div>
      <TopologyView />
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {sim.pods.map((pod) => {
          const primary = sim.links.find((l) => l.id === pod.primaryLink);
          const backup = sim.links.find((l) => l.id === pod.backupLink);
          return (
            <Card key={pod.id}>
              <CardHeader>
                <CardTitle>
                  {pod.podId} · {pod.podName}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 text-xs text-muted">
                <p>Status {pod.status}</p>
                <p>Heartbeat {pod.heartbeatStatus}</p>
                <p>
                  Primary {primary?.status} · Backup {backup?.status}
                </p>
                <p>{pod.connectedDevices.length} attached devices</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
