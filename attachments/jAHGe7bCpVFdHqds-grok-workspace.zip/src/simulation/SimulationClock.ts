import { SIMULATION_DURATION } from "@/models/types";

export class SimulationClock {
  currentTime = 0;
  running = false;
  completed = false;

  start() {
    if (this.completed) return;
    this.running = true;
  }

  pause() {
    this.running = false;
  }

  reset() {
    this.currentTime = 0;
    this.running = false;
    this.completed = false;
  }

  tick(): { time: number; completed: boolean } {
    if (!this.running || this.completed) {
      return { time: this.currentTime, completed: this.completed };
    }
    this.currentTime += 1;
    if (this.currentTime >= SIMULATION_DURATION) {
      this.currentTime = SIMULATION_DURATION;
      this.running = false;
      this.completed = true;
    }
    return { time: this.currentTime, completed: this.completed };
  }
}
