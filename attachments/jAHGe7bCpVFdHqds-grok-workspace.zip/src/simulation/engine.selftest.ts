import { SimulationEngine } from "@/simulation/SimulationEngine";
import { PRIMARY_ATTACK_DEVICE } from "@/models/types";

export function runEngineSelfTest(): string[] {
  const errors: string[] = [];
  const engine = new SimulationEngine();
  if (engine.state.devices.length !== 120) errors.push(`devices ${engine.state.devices.length}`);
  if (engine.state.pods.length !== 8) errors.push(`pods ${engine.state.pods.length}`);
  if (engine.state.zones.length !== 5) errors.push(`zones ${engine.state.zones.length}`);
  if (engine.state.links.length !== 16) errors.push(`links ${engine.state.links.length}`);

  engine.start();
  engine.stepN(44);
  const before = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  if (before.currentSecurityState !== "CLEAR ACCESS") {
    errors.push(`pre-attack state ${before.currentSecurityState}`);
  }

  engine.stepN(10);
  const attacker = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  if (attacker.threatScore < 40) errors.push(`threat ${attacker.threatScore}`);
  if (attacker.policyViolations < 1) errors.push("no policy violations");
  if (attacker.currentSecurityState === "CLEAR ACCESS") errors.push("attacker still clear");

  const isolatedState = attacker.currentSecurityState;
  engine.stepN(21);
  const afterFail = engine.state.devices.find((d) => d.deviceName === PRIMARY_ATTACK_DEVICE)!;
  if (afterFail.currentSecurityState !== isolatedState) {
    errors.push(`failover reset security ${isolatedState} -> ${afterFail.currentSecurityState}`);
  }
  const pod = engine.state.pods.find((p) => p.podId === "POD-01")!;
  if (pod.status !== "failover") errors.push(`pod status ${pod.status}`);
  const primary = engine.state.links.find((l) => l.id === pod.primaryLink)!;
  const backup = engine.state.links.find((l) => l.id === pod.backupLink)!;
  if (!primary.failed) errors.push("primary not failed");
  if (backup.status !== "active") errors.push(`backup ${backup.status}`);

  const types = new Set(engine.state.events.map((e) => e.eventType));
  for (const needed of [
    "ATTACK_INJECTED",
    "POLICY_VIOLATION",
    "LINK_FAILURE",
    "HEARTBEAT_TIMEOUT",
    "FAILOVER_ACTIVATED",
    "STATE_SYNCHRONIZED",
  ] as const) {
    if (!types.has(needed)) errors.push(`missing event ${needed}`);
  }

  return errors;
}
