import { ZONE_LABEL } from "@/components/sim/labels";
import { cn } from "@/lib/utils";
import type { Device, NetworkLink, SmartPod, ZoneId } from "@/models/types";
import { useSimStore, useSimulation } from "@/store/simulation-store";

const ZONE_ORDER: ZoneId[] = ["academic", "student", "administration", "surveillance", "iot"];

function linkColor(link: NetworkLink): string {
  if (link.status === "failed" || link.failed) return "stroke-danger";
  if (link.status === "congested") return "stroke-warn";
  if (link.status === "active") return "stroke-accent";
  if (link.status === "standby") return "stroke-subtle";
  return "stroke-ok";
}

function podGlow(pod: SmartPod): string {
  if (pod.status === "failover") return "glow-pod-warn";
  if (pod.status === "degraded") return "glow-pod-warn";
  if (pod.status === "offline") return "glow-pod-danger";
  return "glow-pod";
}

export function TopologyView({ compact = false }: { compact?: boolean }) {
  const snapshot = useSimulation();
  const select = useSimStore((s) => s.selectDevice);

  return (
    <div className="min-w-0">
      <div className="mb-4 flex flex-col items-center">
        <div className="rounded-xl border border-accent/30 bg-elevated px-6 py-3 text-center shadow-[var(--shadow-border)]">
          <p className="kicker">Core</p>
          <p className="font-mono text-sm text-accent">{snapshot.core.name}</p>
          <p className="text-xs text-muted">
            Health {snapshot.core.networkHealth.toFixed(0)} · Links {snapshot.core.activeLinks} up /{" "}
            {snapshot.core.failedLinks} failed
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-5">
        {ZONE_ORDER.map((zoneId) => {
          const zone = snapshot.zones.find((z) => z.id === zoneId)!;
          const pods = snapshot.pods.filter((p) => p.zone === zoneId);
          const devices = snapshot.devices.filter((d) => d.zone === zoneId);
          const preview = compact
            ? [
                ...devices.filter((d) => d.currentSecurityState !== "CLEAR ACCESS"),
                ...devices,
              ]
                .filter((d, i, arr) => arr.findIndex((x) => x.id === d.id) === i)
                .slice(0, 12)
            : devices;
          return (
            <section key={zoneId} className="rounded-xl bg-surface p-3 shadow-[var(--shadow-border)]">
              <header className="mb-3">
                <p className="kicker">{ZONE_LABEL[zoneId]}</p>
                <p className="text-xs text-muted">
                  {zone.cidr} · {zone.deviceCount} devices
                </p>
              </header>
              <div className="flex flex-wrap gap-2">
                {pods.map((pod) => {
                  const primary = snapshot.links.find((l) => l.id === pod.primaryLink);
                  const backup = snapshot.links.find((l) => l.id === pod.backupLink);
                  return (
                    <div key={pod.id} className="flex flex-col items-center gap-1">
                      <div
                        className={cn(
                          "flex size-12 items-center justify-center rounded-full bg-bg font-mono text-[0.65rem] text-accent",
                          podGlow(pod),
                        )}
                        title={pod.podName}
                      >
                        {pod.podId.replace("POD-0", "P")}
                      </div>
                      <div className="flex gap-1">
                        <LinkTick link={primary} label="P" />
                        <LinkTick link={backup} label="B" />
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className={cn("mt-3 grid gap-1", compact ? "grid-cols-6" : "grid-cols-6 sm:grid-cols-8")}>
                {preview.map((device) => (
                  <DeviceDot key={device.id} device={device} onClick={() => select(device.id)} />
                ))}
              </div>
              {compact && devices.length > preview.length ? (
                <p className="mt-2 text-[0.7rem] text-subtle">+{devices.length - preview.length} more</p>
              ) : null}
            </section>
          );
        })}
      </div>
    </div>
  );
}

function LinkTick({ link, label }: { link?: NetworkLink; label: string }) {
  if (!link) return null;
  return (
    <span
      className={cn("font-mono text-[0.6rem]", linkColor(link).replace("stroke-", "text-"))}
      title={`${link.name} · ${link.status}`}
    >
      {label}
    </span>
  );
}

function DeviceDot({ device, onClick }: { device: Device; onClick: () => void }) {
  const tone =
    device.currentSecurityState === "NETWORK-WIDE QUARANTINE"
      ? "bg-danger"
      : device.currentSecurityState === "RESTRICTED ISOLATION"
        ? "bg-warn"
        : device.currentSecurityState === "BANDWIDTH THROTTLED"
          ? "bg-accent"
          : device.currentSecurityState === "HEURISTIC ALERT"
            ? "bg-warn/70"
            : "bg-ok";
  return (
    <button
      type="button"
      onClick={onClick}
      title={`${device.deviceName} · ${device.currentSecurityState}`}
      className={cn("size-3 rounded-full", tone)}
      aria-label={device.deviceName}
    />
  );
}
