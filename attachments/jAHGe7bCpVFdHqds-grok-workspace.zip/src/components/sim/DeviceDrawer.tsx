import { Sheet, SheetContent } from "@/components/ui/sheet";
import { StateBadge } from "@/components/sim/StateBadge";
import { ZONE_LABEL } from "@/components/sim/labels";
import { formatInteger, formatNumber } from "@/lib/utils";
import type { Device, SimEvent } from "@/models/types";
import { useSimStore } from "@/store/simulation-store";

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="grid grid-cols-[8.5rem_1fr] gap-2 border-b border-border py-2 text-sm">
      <dt className="text-muted">{label}</dt>
      <dd className="font-mono text-fg tabular">{value}</dd>
    </div>
  );
}

export function DeviceDrawer() {
  const selected = useSimStore((s) => s.selectedDeviceId);
  const select = useSimStore((s) => s.selectDevice);
  const snapshot = useSimStore((s) => s.snapshot);
  const device: Device | undefined = snapshot.devices.find(
    (d) => d.id === selected || d.deviceName === selected,
  );
  const events: SimEvent[] = device
    ? snapshot.events.filter((e) => e.deviceId === device.deviceName).slice(0, 8)
    : [];

  return (
    <Sheet open={Boolean(device)} onOpenChange={(open) => !open && select(null)}>
      {device ? (
        <SheetContent title={device.deviceName} side="right">
          <div className="px-5 py-4">
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <StateBadge state={device.currentSecurityState} />
              <span className="text-xs text-muted">{device.role}</span>
            </div>
            <dl>
              <Field label="Identity" value={device.deviceId} />
              <Field label="IP address" value={device.ipAddress} />
              <Field label="Zone" value={ZONE_LABEL[device.zone]} />
              <Field label="Smart Pod" value={device.connectedPod} />
              <Field label="Type" value={device.deviceType} />
              <Field label="Packet rate" value={`${formatNumber(device.packetRate, 1)} pps`} />
              <Field label="Threat score" value={formatNumber(device.threatScore, 1)} />
              <Field label="Security state" value={device.currentSecurityState} />
              <Field label="Policy violations" value={formatInteger(device.policyViolations)} />
              <Field
                label="Destination ports"
                value={device.destinationPorts.length ? device.destinationPorts.join(", ") : "—"}
              />
              <Field label="Packets sent" value={formatInteger(device.packetsSent)} />
              <Field label="Packets received" value={formatInteger(device.packetsReceived)} />
              <Field label="Last event" value={device.lastEvent || "—"} />
            </dl>
            <p className="kicker mt-6 mb-2">Recent events</p>
            <ul className="space-y-2">
              {events.length === 0 ? (
                <li className="text-sm text-muted">No device events yet.</li>
              ) : (
                events.map((event) => (
                  <li key={event.id} className="rounded-lg bg-elevated px-3 py-2 text-xs">
                    <p className="font-mono text-accent">
                      t={event.simulationTime}s · {event.eventType}
                    </p>
                    <p className="mt-1 text-muted">{event.description}</p>
                  </li>
                ))
              )}
            </ul>
          </div>
        </SheetContent>
      ) : null}
    </Sheet>
  );
}
