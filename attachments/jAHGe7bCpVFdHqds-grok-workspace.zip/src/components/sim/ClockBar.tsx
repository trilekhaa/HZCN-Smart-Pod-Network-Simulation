import { Pause, Play, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatSimTime } from "@/lib/utils";
import { SCHEDULED_ATTACK_AT, SCHEDULED_FAILURE_AT, SIMULATION_DURATION } from "@/models/types";
import { useSimStore } from "@/store/simulation-store";

export function ClockBar() {
  const snapshot = useSimStore((s) => s.snapshot);
  const start = useSimStore((s) => s.start);
  const pause = useSimStore((s) => s.pause);
  const reset = useSimStore((s) => s.reset);
  const progress = (snapshot.currentTime / SIMULATION_DURATION) * 100;

  return (
    <div className="flex min-w-0 flex-col gap-2">
      <div className="flex flex-wrap items-center gap-2">
        <span className="kicker">Simulation clock</span>
        <span className="font-mono text-lg text-accent tabular">
          {formatSimTime(snapshot.currentTime)}
          <span className="text-muted"> / {formatSimTime(SIMULATION_DURATION)}</span>
        </span>
        {snapshot.scenario.completed ? (
          <span className="text-xs text-muted">Complete</span>
        ) : snapshot.running ? (
          <span className="text-xs text-ok">Running</span>
        ) : (
          <span className="text-xs text-muted">Paused</span>
        )}
      </div>
      <div className="relative h-1.5 overflow-hidden rounded-full bg-elevated">
        <div
          className="absolute inset-y-0 left-0 bg-accent transition-[width] duration-300"
          style={{ width: `${progress}%` }}
        />
        <span
          className="absolute top-1/2 size-1.5 -translate-y-1/2 rounded-full bg-warn"
          style={{ left: `${(SCHEDULED_ATTACK_AT / SIMULATION_DURATION) * 100}%` }}
          title="Attack at 45s"
        />
        <span
          className="absolute top-1/2 size-1.5 -translate-y-1/2 rounded-full bg-danger"
          style={{ left: `${(SCHEDULED_FAILURE_AT / SIMULATION_DURATION) * 100}%` }}
          title="Link failure at 75s"
        />
      </div>
      <div className="flex flex-wrap gap-2">
        {snapshot.running ? (
          <Button size="sm" variant="outline" onClick={pause}>
            <Pause className="size-3.5" />
            Pause
          </Button>
        ) : (
          <Button size="sm" onClick={start} disabled={snapshot.scenario.completed}>
            <Play className="size-3.5" />
            Start
          </Button>
        )}
        <Button size="sm" variant="ghost" onClick={reset}>
          <RotateCcw className="size-3.5" />
          Reset
        </Button>
      </div>
    </div>
  );
}
