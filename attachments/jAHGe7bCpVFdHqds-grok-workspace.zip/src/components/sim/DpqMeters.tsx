import type { DpqStats } from "@/models/types";

const ROWS = [
  { key: "critical", label: "CRITICAL", drop: "criticalDrop" },
  { key: "high", label: "HIGH", drop: "highDrop" },
  { key: "normal", label: "NORMAL", drop: "normalDrop" },
  { key: "background", label: "BACKGROUND", drop: "backgroundDrop" },
] as const;

export function DpqMeters({ dpq }: { dpq: DpqStats }) {
  return (
    <div className="space-y-3">
      {ROWS.map((row) => {
        const fill = dpq[row.key];
        const drop = dpq[row.drop] * 100;
        return (
          <div key={row.key}>
            <div className="mb-1 flex items-center justify-between text-xs">
              <span className="font-mono text-muted">{row.label}</span>
              <span className="font-mono text-subtle tabular">{drop.toFixed(0)}% drop</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-elevated">
              <div className="h-full bg-accent" style={{ width: `${Math.min(100, fill)}%` }} />
            </div>
          </div>
        );
      })}
      <p className="text-xs text-subtle">Simulated DPQ — not Linux traffic control. Capacity {dpq.capacity.toFixed(0)} pps.</p>
    </div>
  );
}
